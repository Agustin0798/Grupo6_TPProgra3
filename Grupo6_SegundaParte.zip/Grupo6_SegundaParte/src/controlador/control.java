package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.InvalidParameterException;

import Negocio.Observable;
import Negocio.Observador;
import datos.Abonado;
import vista.IVista;
import Negocio.BancoDatos;
import datos.Abonado;
import Negocio.BancoDatos;
import Negocio.Solicitante;

public class control implements ActionListener,Observador {
	
	private IVista view;
	private BancoDatos databank;

	public control(IVista view, BancoDatos databank) 
	{
		this.view = view;
		this.model = Factura;
		this.model.getFacturas();
		this.view.action(null, model);
		this.databank = databank;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String comando = e.getActionCommand();
		if (comando.equalsIgnoreCase("ListaAbonados"))//pide datos a la lista de abonados
		{
				 Arraylist<Abonado> Abonadoslist =(ArrayList<Abonado>)this.databank.getAbonados;//esta mal
				 this.databank.addobserver(this);
		}
		 if (comando.equalsIgnoreCase("ListaFactura"))
		 {
			 String FacturaList =  (String)this.databank.getAbonados
			 this.databank.getarrayFactura();
		 }
		} 
		else if (comando.equalsIgnoreCase("Solicitar Tecnico"))
		{
			this.solicitar();
		}
		} else if (comando.equalsIgnoreCase(""))
		{
		
		}
	}
	public void solicitar() {
		Thread t = new Thread();
		Runneble s= new Solicitante;
		
		t.start(s);
	}
	public void update(String string) {
		// TODO Auto-generated method stub
		
	}
}
