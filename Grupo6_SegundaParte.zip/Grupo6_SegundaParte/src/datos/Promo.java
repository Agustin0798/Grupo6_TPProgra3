package datos;

public interface Promo {
	
	public double masMComercio(double costo);
	public double masMVivienda(double costo);
}
