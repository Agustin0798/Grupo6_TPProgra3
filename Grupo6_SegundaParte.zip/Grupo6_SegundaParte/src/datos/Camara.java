package datos;

public class Camara extends Adicional{
	
	public Camara()
	{
		super.setCostoAdicional(3000);
	}
}
