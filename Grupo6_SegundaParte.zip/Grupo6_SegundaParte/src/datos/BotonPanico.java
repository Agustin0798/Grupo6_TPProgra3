package datos;

public class BotonPanico extends Adicional{

	public BotonPanico()
	{
		super.setCostoAdicional(2000);
	}
}
