package datos;

import java.io.Serializable;

public class Tecnico implements Serializable{

	private int id;
	
	public Tecnico(int id)
	{
		this.id=id;
	}
	
	public int getId() {
		
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
