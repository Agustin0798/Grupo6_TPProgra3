package datos;

public class Vigilante extends Adicional{
	
	public Vigilante()
	{
		super.setCostoAdicional(7500);
	}
}
