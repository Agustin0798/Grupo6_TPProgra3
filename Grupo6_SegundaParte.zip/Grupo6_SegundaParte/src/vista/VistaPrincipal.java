package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.SpringLayout;
import java.awt.Component;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Button;
import java.awt.Font;

public class VistaPrincipal extends JFrame implements IVista{

	private JPanel contentPane;
	private Object btnClientes;
	private ActionListener actionListener;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaPrincipal frame = new VistaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 64));
		contentPane.setBorder(null);

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 2, 0, 0));
		
		JPanel Clientes = new JPanel();
		contentPane.add(Clientes);
		Clientes.setLayout(new GridLayout(3, 2, 0, 0));
		
		JPanel arriba_c = new JPanel();
		arriba_c.setBackground(new Color(181, 181, 255));
		Clientes.add(arriba_c);
		arriba_c.setLayout(new GridLayout(1, 0, 0, 0));
		
		Panel centro_c = new Panel();
		Clientes.add(centro_c);
		centro_c.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel_c = new JPanel();
		centro_c.add(panel_c);
		panel_c.setLayout(new GridLayout(0, 1, 0, 0));
		
		Panel abajo_c = new Panel();
		abajo_c.setBackground(new Color(181, 181, 255));
		Clientes.add(abajo_c);
		
		
		JPanel Tecnicos = new JPanel();
		contentPane.add(Tecnicos);
		Tecnicos.setLayout(new GridLayout(3, 2, 0, 0));
		
		JPanel arriba_t = new JPanel();
		arriba_t.setBackground(new Color(181, 181, 255));
		Tecnicos.add(arriba_t);
		arriba_t.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel centro_t = new JPanel();
		Tecnicos.add(centro_t);
		centro_t.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel_t = new JPanel();
		centro_t.add(panel_t);
		panel_t.setLayout(new GridLayout(0, 1, 0, 0));
		
		JButton btnClientes = new JButton("Funcionalidades Tecnicos");
		btnClientes.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		panel_t.add(btnClientes);
		btnClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton btnTecnicos = new JButton("Funcionalidades Clientes");
		btnTecnicos.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		btnTecnicos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_c.setLayout(new GridLayout(0, 1, 0, 0));
		panel_c.add(btnTecnicos);
		
		JPanel abajo_t = new JPanel();
		abajo_t.setBackground(new Color(181, 181, 255));
		Tecnicos.add(abajo_t);
		abajo_t.setLayout(new GridLayout(1, 0, 0, 0));
		
	}
	
	public void cerrar() {
		this.dispose();
	}

	public void mostrar() {
		this.setVisible(true);
	}
	
	public void setActionListener(ActionListener actionListener) {
		((JTextField) this.btnClientes).addActionListener(actionListener);
		this.actionListener=actionListener;
		
	}
}
