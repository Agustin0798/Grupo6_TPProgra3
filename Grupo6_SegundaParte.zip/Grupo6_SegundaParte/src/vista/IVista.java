package vista;

import java.awt.event.ActionListener;

public interface IVista {

    void cerrar();

    void mostrar();

    void setActionListener(ActionListener actionListener);
}
