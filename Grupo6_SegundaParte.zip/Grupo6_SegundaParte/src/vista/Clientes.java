package vista;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;

public class Clientes extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clientes frame = new Clientes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Clientes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 2, 0, 0));
		
		JPanel izquierda = new JPanel();
		contentPane.add(izquierda);
		izquierda.setLayout(new GridLayout(2, 0, 0, 0));
		
		JPanel arriba_I = new JPanel();
		arriba_I.setBackground(new Color(181, 181, 255));
		izquierda.add(arriba_I);
		arriba_I.setLayout(new GridLayout(3, 3, 0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(181, 181, 255));
		arriba_I.add(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		JButton btnPagar = new JButton("Pagar");
		arriba_I.add(btnPagar);
		btnPagar.setBackground(new Color(255, 255, 255));
		btnPagar.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		btnPagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		
		JPanel abajo_I = new JPanel();
		abajo_I.setBackground(new Color(181, 181, 255));
		izquierda.add(abajo_I);
		
		JButton btnModificar = new JButton("Modificar Servicio");
		btnModificar.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		abajo_I.setLayout(new GridLayout(3, 3, 0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(181, 181, 255));
		abajo_I.add(panel_1);
		abajo_I.add(btnModificar);
		
		
		JPanel derecha = new JPanel();
		contentPane.add(derecha);
		derecha.setLayout(new GridLayout(2, 0, 0, 0));
		
		JPanel arriba_D = new JPanel();
		arriba_D.setBackground(new Color(181, 181, 255));
		derecha.add(arriba_D);
		
		JButton btnContratar = new JButton("Contratar Servicio");
		btnContratar.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		btnContratar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		arriba_D.setLayout(new GridLayout(3, 3, 0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(181, 181, 255));
		arriba_D.add(panel_2);
		arriba_D.add(btnContratar);
		
		
		JPanel abajo_D = new JPanel();
		abajo_D.setBackground(new Color(181, 181, 255));
		derecha.add(abajo_D);
		
		JButton btnSolicitar = new JButton("Solicitar Tecnico");
		btnSolicitar.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		btnSolicitar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		abajo_D.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(181, 181, 255));
		abajo_D.add(panel_3);
		abajo_D.add(btnSolicitar);
		
	}

}
