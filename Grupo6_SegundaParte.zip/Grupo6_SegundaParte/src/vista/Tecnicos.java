package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.CardLayout;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;

public class Tecnicos extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tecnicos frame = new Tecnicos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tecnicos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 2, 0, 0));
		
		JPanel Derecha = new JPanel();
		Derecha.setBackground(new Color(181, 181, 255));
		contentPane.add(Derecha);
		Derecha.setLayout(new GridLayout(3, 3, 0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(181, 181, 255));
		Derecha.add(panel);
		
		JButton btnNewButton = new JButton("Agregar Tecnico");
		btnNewButton.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		Derecha.add(btnNewButton);
		
		JPanel Izquierda = new JPanel();
		Izquierda.setBackground(new Color(181, 181, 255));
		contentPane.add(Izquierda);
		Izquierda.setLayout(new GridLayout(3, 3, 0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(181, 181, 255));
		Izquierda.add(panel_1);
		
		JButton btnNewButton_1 = new JButton("Remover Tecnico");
		btnNewButton_1.setFont(new Font("Tw Cen MT", Font.PLAIN, 18));
		Izquierda.add(btnNewButton_1);
	}

}
