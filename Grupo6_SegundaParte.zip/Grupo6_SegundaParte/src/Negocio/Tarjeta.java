package Negocio;

public class Tarjeta extends DecoMedPago{

	public Tarjeta(Pago pago) {
		super(pago);
	}

	@Override
	public double pagar(double costo) {
		
		return costo*1.05;
	}
}
