package Negocio;

public class Pago {
	
	public double pagar(double costo) {
		
		return costo;
	}
}
