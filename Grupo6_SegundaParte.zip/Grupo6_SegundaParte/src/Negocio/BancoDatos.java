package Negocio;


import java.util.ArrayList;
import java.time.LocalDate;
import java.time.Month;

import datos.Abonado;
import datos.Contratacion;
import datos.Factura;
import datos.Moroso;
import datos.Tecnico;

public class BancoDatos extends Observable{

	private ArrayList<Abonado> abonados;
	private ArrayList<Tecnico> tecnicos;
	private LocalDate fecha;
	
	public BancoDatos(ArrayList<Abonado> abonados, ArrayList<Tecnico> tecnicos, LocalDate fecha) {
		
		this.tecnicos=tecnicos;
		this.abonados=abonados;
		this.fecha=fecha;
	}

	public ArrayList<Abonado> getAbonados() {
		return this.abonados;
	}

	public void setAbonados(ArrayList<Abonado> abonados) {
		this.abonados = abonados;
	}

	public ArrayList<Tecnico> getTecnicos() {
		return this.tecnicos;
	}

	public void setTecnicos(ArrayList<Tecnico> tecnicos) {
		this.tecnicos = tecnicos;
	}
	
	public LocalDate getFecha() {
		return this.fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public void addAbonado(Abonado abonado) {
		
		this.abonados.add(abonado);
		this.notifyObserver("Abonado registrado con exito.");
	}
	public void removeAbonado(Abonado abonado) {
		
		this.abonados.remove(abonado);
		this.notifyObserver("Abonado eliminado con exito.");
	}
	
	public void cambiaFecha() {
		
		Month m=this.fecha.getMonth();
		ArrayList<Abonado> ab=this.abonados;
		
		if (m==Month.DECEMBER)
			this.fecha=LocalDate.of(this.fecha.getYear()+1,Month.JANUARY,this.fecha.getDayOfMonth());
		else
			this.fecha=LocalDate.of(this.fecha.getYear(),m.getValue()+1,this.fecha.getDayOfMonth());
		for (Abonado a:ab)
		{
			double costo=0;
			for (Contratacion c:a.getContrataciones())
			{
				costo+=c.getCosto();
			}
			
			Factura f=new Factura(this.fecha, costo);
			int i=0;
			Boolean cumple=true;
			
			while (i<a.getFacturas().size() && cumple)
			{
				if (i>0 && a.getFacturas().get(i).getPagado()==false && a.getFacturas().get(i-1).getPagado()==false)
					cumple=false;
				else
					i++;
			}
			if (!cumple)
				a.setEstado(new Moroso(a));
			a.getFacturas().add(f);
		}
		this.notifyObserver("Cambio de fecha y emision de facturas exitosa.");
	}
	
	public synchronized Tecnico solicita(Solicitante solicitante) {
		
		Tecnico t;
		
		while (this.tecnicos.isEmpty())
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		t=this.tecnicos.remove(0);
		this.notifyObserver("Tecnico Solicitado.");
		notifyAll();
		return t;
	}

	public synchronized void addTecnico(Tecnico t) {
		
		this.tecnicos.add(t);
		this.notifyObserver("Tecnico contratado.");
		notifyAll();
	}
	
	public synchronized void removeTecnico(Tecnico t) {
		
		this.tecnicos.remove(t);
		this.notifyObserver("Tecnico despedido.");
		notifyAll();
	}

	@Override
	public void notifyObserver(String string) {
		
		super.getObservador().update(string);
	}
}
