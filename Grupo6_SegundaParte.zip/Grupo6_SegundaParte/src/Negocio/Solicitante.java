package Negocio;

import java.lang.Thread;

import datos.Tecnico;

public class Solicitante implements Runnable{
	
	private String nombre;
	private int dni;
	private BancoDatos datos;
	
	public Solicitante(String nombre, int dni, BancoDatos datos) {
		
		this.nombre=nombre;
		this.dni=dni;
		this.datos=datos;
	}

	public void run() {
		
		Tecnico t;
		
		t=this.datos.solicita(this);
		try {
			Thread.sleep((int) (Math.random() * 100));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.datos.addTecnico(t);
	}
}
