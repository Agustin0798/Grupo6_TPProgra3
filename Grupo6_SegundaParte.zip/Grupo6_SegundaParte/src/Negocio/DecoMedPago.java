package Negocio;


public abstract class DecoMedPago extends Pago{
	
	Pago pago;
	
	public DecoMedPago(Pago pago)
	{
		this.pago=pago;
	}
	
	public abstract double pagar(double costo);
}
