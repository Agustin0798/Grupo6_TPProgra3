package Negocio;

public interface Observador {

	public void update(String string);
}
