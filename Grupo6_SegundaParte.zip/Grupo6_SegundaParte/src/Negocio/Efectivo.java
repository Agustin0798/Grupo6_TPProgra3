package Negocio;

public class Efectivo extends DecoMedPago{

	public Efectivo(Pago pago)
	{
		super(pago);
	}

	@Override
	public double pagar(double costo) {
		return costo*0.8;
	}
}
