package Negocio;

public class Cheque extends DecoMedPago{

	public Cheque(Pago pago) {
		super(pago);
	}

	@Override
	public double pagar(double costo) {
		
		return costo*1.1;
	}

}
